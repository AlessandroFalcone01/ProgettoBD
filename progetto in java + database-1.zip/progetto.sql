CREATE DATABASE  IF NOT EXISTS `progetto` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `progetto`;
-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: progetto
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accessoria`
--

DROP TABLE IF EXISTS `accessoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accessoria` (
  `nome` varchar(20) NOT NULL,
  `descrizione_d'uso` varchar(100) NOT NULL,
  `applicabile` tinyint NOT NULL,
  PRIMARY KEY (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accessoria`
--

LOCK TABLES `accessoria` WRITE;
/*!40000 ALTER TABLE `accessoria` DISABLE KEYS */;
INSERT INTO `accessoria` VALUES ('crema','crema per massaggi',1),('lampada','lampada per lettini',1),('termocoperta','termocoperta per lettini',1);
/*!40000 ALTER TABLE `accessoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assegnazione`
--

DROP TABLE IF EXISTS `assegnazione`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assegnazione` (
  `progetto` int NOT NULL,
  `dipendente` char(16) NOT NULL,
  PRIMARY KEY (`progetto`,`dipendente`),
  KEY `dipendente_idx` (`dipendente`),
  CONSTRAINT `dipendente_cf` FOREIGN KEY (`dipendente`) REFERENCES `dipendente` (`CF`) ON UPDATE CASCADE,
  CONSTRAINT `progetto_id` FOREIGN KEY (`progetto`) REFERENCES `progetto` (`ID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assegnazione`
--

LOCK TABLES `assegnazione` WRITE;
/*!40000 ALTER TABLE `assegnazione` DISABLE KEYS */;
INSERT INTO `assegnazione` VALUES (374,'3333333333333334'),(876,'3333333333333334'),(359,'3333333333333335'),(374,'3333333333333335'),(863,'3333333333333335'),(876,'3333333333333335'),(346,'3333333333333337');
/*!40000 ALTER TABLE `assegnazione` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `base`
--

DROP TABLE IF EXISTS `base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `base` (
  `nome` varchar(20) NOT NULL,
  `descrizione_d'uso` varchar(100) NOT NULL,
  `lunghezza` double NOT NULL,
  `larghezza` double NOT NULL,
  `altezza` double NOT NULL,
  `trattamenti` varchar(100) NOT NULL,
  PRIMARY KEY (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `base`
--

LOCK TABLES `base` WRITE;
/*!40000 ALTER TABLE `base` DISABLE KEYS */;
INSERT INTO `base` VALUES ('autoclave','sterlizzante per estetica ',1,1,1,'sterilizza'),('claudine','sauna',3,2,3,'sauna singola'),('lettino','massaggi',2,1,1,'estetici');
/*!40000 ALTER TABLE `base` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente` (
  `CF` char(16) NOT NULL,
  `nome` varchar(20) NOT NULL,
  `cognome` varchar(30) NOT NULL,
  `#telefono` varchar(11) NOT NULL,
  `acquisti_effettuati` int NOT NULL,
  `via` varchar(20) NOT NULL,
  `cap` char(5) NOT NULL,
  `città` varchar(20) NOT NULL,
  PRIMARY KEY (`CF`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES ('1111111111111111','biagio','andreucci','1234567897',3,'vulture','85027','rapolla'),('3333333333333333','alessandro','falcone','1234567890',2,'michelangelo','81055','caserta'),('8888888888888888','alberto','rossi','3457890921',1,'madonne','21094','rapolla city');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `coinvolgimenti`
--

DROP TABLE IF EXISTS `coinvolgimenti`;
/*!50001 DROP VIEW IF EXISTS `coinvolgimenti`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `coinvolgimenti` AS SELECT 
 1 AS `dipendente`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `coinvolgimento`
--

DROP TABLE IF EXISTS `coinvolgimento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coinvolgimento` (
  `dipendente` char(16) NOT NULL,
  `intervento` char(5) NOT NULL,
  `macchinario` char(7) NOT NULL,
  `data_inizio` date NOT NULL,
  `data_fine` date DEFAULT NULL,
  `#ore_dell'intervento` int DEFAULT NULL,
  PRIMARY KEY (`dipendente`,`intervento`,`macchinario`),
  KEY `intervento_idx` (`intervento`),
  KEY `macchianrio_int_idx` (`macchinario`),
  CONSTRAINT `Dipendete_cf` FOREIGN KEY (`dipendente`) REFERENCES `dipendente` (`CF`) ON UPDATE CASCADE,
  CONSTRAINT `Intervento_prog` FOREIGN KEY (`intervento`) REFERENCES `intervento` (`progressivo`) ON UPDATE CASCADE,
  CONSTRAINT `macchianrio_int` FOREIGN KEY (`macchinario`) REFERENCES `macchinario` (`cod_seriale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coinvolgimento`
--

LOCK TABLES `coinvolgimento` WRITE;
/*!40000 ALTER TABLE `coinvolgimento` DISABLE KEYS */;
INSERT INTO `coinvolgimento` VALUES ('3333333333333334','12341','1234563','2021-04-23','2021-04-30',NULL),('3333333333333334','23457','1234569','2021-11-30',NULL,NULL),('3333333333333335','12342','1234561','2021-04-13',NULL,NULL),('3333333333333335','12373','1234568','2021-04-13',NULL,NULL),('3333333333333337','12345','1234567','2021-05-12',NULL,NULL);
/*!40000 ALTER TABLE `coinvolgimento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `corriere`
--

DROP TABLE IF EXISTS `corriere`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `corriere` (
  `codice_id` char(6) NOT NULL,
  `data_primo_impiego` date NOT NULL,
  `società` varchar(30) NOT NULL,
  `targa` char(7) NOT NULL,
  PRIMARY KEY (`codice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `corriere`
--

LOCK TABLES `corriere` WRITE;
/*!40000 ALTER TABLE `corriere` DISABLE KEYS */;
INSERT INTO `corriere` VALUES ('123','2021-12-09','soccer','AM782MP'),('345','2020-11-12','calcio','BG380PO');
/*!40000 ALTER TABLE `corriere` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dipendente`
--

DROP TABLE IF EXISTS `dipendente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dipendente` (
  `CF` char(16) NOT NULL,
  `nome` varchar(20) NOT NULL,
  `cognome` varchar(20) NOT NULL,
  `data_di_nascita` date NOT NULL,
  `#telefono` varchar(11) NOT NULL,
  `tipoContratto` varchar(45) NOT NULL,
  PRIMARY KEY (`CF`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dipendente`
--

LOCK TABLES `dipendente` WRITE;
/*!40000 ALTER TABLE `dipendente` DISABLE KEYS */;
INSERT INTO `dipendente` VALUES ('3333333333333334','paolo','bitta','1987-08-22','4561237890','indetermianto'),('3333333333333335','gino','cane','1976-05-23','0987654321','indeterminato'),('3333333333333336','aldo','baglio','1970-12-25','1230985970','determinato'),('3333333333333337','pietro','bianchi','1960-07-12','7250971583','indeterminato'),('3333333333333338','alberto','ponzio','1950-08-24','4591307935','indeterminato');
/*!40000 ALTER TABLE `dipendente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `dipendentioccupati`
--

DROP TABLE IF EXISTS `dipendentioccupati`;
/*!50001 DROP VIEW IF EXISTS `dipendentioccupati`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `dipendentioccupati` AS SELECT 
 1 AS `dipendente`,
 1 AS `intervento`,
 1 AS `macchinario`,
 1 AS `data_inizio`,
 1 AS `data_fine`,
 1 AS `#ore_dell'intervento`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `ingegnere`
--

DROP TABLE IF EXISTS `ingegnere`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ingegnere` (
  `specializzazione` varchar(50) NOT NULL,
  `albo` varchar(50) NOT NULL,
  `dipendente` char(16) NOT NULL,
  PRIMARY KEY (`dipendente`),
  CONSTRAINT `dipendete` FOREIGN KEY (`dipendente`) REFERENCES `dipendente` (`CF`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingegnere`
--

LOCK TABLES `ingegnere` WRITE;
/*!40000 ALTER TABLE `ingegnere` DISABLE KEYS */;
INSERT INTO `ingegnere` VALUES ('meccanico','ingegnere','3333333333333334'),('informatica','ingegnere','3333333333333337'),('elettronico','ingegnere','3333333333333338');
/*!40000 ALTER TABLE `ingegnere` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `ingegneriliberi`
--

DROP TABLE IF EXISTS `ingegneriliberi`;
/*!50001 DROP VIEW IF EXISTS `ingegneriliberi`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `ingegneriliberi` AS SELECT 
 1 AS `dipendente`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `ingegnerioccupati`
--

DROP TABLE IF EXISTS `ingegnerioccupati`;
/*!50001 DROP VIEW IF EXISTS `ingegnerioccupati`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `ingegnerioccupati` AS SELECT 
 1 AS `dipendente`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `intervento`
--

DROP TABLE IF EXISTS `intervento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `intervento` (
  `progressivo` char(5) NOT NULL,
  `macchinario` char(7) NOT NULL,
  `data_inizio` date NOT NULL,
  `data_fine` date DEFAULT NULL,
  `tipo` varchar(45) NOT NULL,
  `richiesto` tinyint DEFAULT NULL,
  `valutato` tinyint DEFAULT NULL,
  `completato` tinyint DEFAULT NULL,
  `in_lavorazione` tinyint DEFAULT NULL,
  `verificato` tinyint DEFAULT NULL,
  PRIMARY KEY (`progressivo`,`macchinario`),
  KEY `macchinario_idx` (`macchinario`),
  CONSTRAINT `macchinario` FOREIGN KEY (`macchinario`) REFERENCES `macchinario` (`cod_seriale`),
  CONSTRAINT `intervento_chk_1` CHECK (((`tipo` = _utf8mb4'sostituzione') or (`tipo` = _utf8mb4'manutenzione')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `intervento`
--

LOCK TABLES `intervento` WRITE;
/*!40000 ALTER TABLE `intervento` DISABLE KEYS */;
INSERT INTO `intervento` VALUES ('12341','1234563','2021-04-23','2021-04-30','sostituzione',0,0,1,0,0),('12342','1234561','2021-04-13',NULL,'manutenzione',0,0,0,1,0),('12345','1234567','2021-05-12',NULL,'sostituzione',0,0,0,1,0),('12373','1234568','2021-05-12',NULL,'manutenzione',0,0,0,1,0),('23457','1234569','2021-11-30',NULL,'sostituzione',0,0,0,1,0);
/*!40000 ALTER TABLE `intervento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `macchinarimanutenuti`
--

DROP TABLE IF EXISTS `macchinarimanutenuti`;
/*!50001 DROP VIEW IF EXISTS `macchinarimanutenuti`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `macchinarimanutenuti` AS SELECT 
 1 AS `macchinario`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `macchinarinonmanutenuti`
--

DROP TABLE IF EXISTS `macchinarinonmanutenuti`;
/*!50001 DROP VIEW IF EXISTS `macchinarinonmanutenuti`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `macchinarinonmanutenuti` AS SELECT 
 1 AS `cod_seriale`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `macchinario`
--

DROP TABLE IF EXISTS `macchinario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `macchinario` (
  `cod_seriale` char(7) NOT NULL,
  `prezzo` double NOT NULL,
  `#lotto` int NOT NULL,
  `descrizione` varchar(100) NOT NULL,
  `progetto` int NOT NULL,
  `acquirente` char(16) DEFAULT NULL,
  `base` varchar(20) DEFAULT NULL,
  `accessoria` varchar(20) DEFAULT NULL,
  `corriere` char(6) DEFAULT NULL,
  PRIMARY KEY (`cod_seriale`),
  KEY `acquirente_idx` (`acquirente`),
  KEY `base_idx` (`base`),
  KEY `accessoria_idx` (`accessoria`),
  KEY `corriere_idx` (`corriere`),
  KEY `progetto_idx` (`progetto`),
  CONSTRAINT `accessoria` FOREIGN KEY (`accessoria`) REFERENCES `accessoria` (`nome`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `acquirente` FOREIGN KEY (`acquirente`) REFERENCES `cliente` (`CF`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `base` FOREIGN KEY (`base`) REFERENCES `base` (`nome`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `corriere` FOREIGN KEY (`corriere`) REFERENCES `corriere` (`codice_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `progetto` FOREIGN KEY (`progetto`) REFERENCES `progetto` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `macchinario`
--

LOCK TABLES `macchinario` WRITE;
/*!40000 ALTER TABLE `macchinario` DISABLE KEYS */;
INSERT INTO `macchinario` VALUES ('1234512',450,23,'crema',123,'8888888888888888',NULL,'crema','123'),('1234561',2000,1,'sauna singola',346,'3333333333333333','claudine',NULL,'123'),('1234563',100,2,'termocoperta per lettini',359,'1111111111111111',NULL,'termocoperta','345'),('1234567',200,12,'lettino per massaggi',374,'1111111111111111','lettino',NULL,'123'),('1234568',500,5,'sterilizzante per estetica',863,'3333333333333333','autoclave',NULL,'123'),('1234569',70,3,'lampada per lettini',876,'1111111111111111',NULL,'lampada','123');
/*!40000 ALTER TABLE `macchinario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `manutenzione`
--

DROP TABLE IF EXISTS `manutenzione`;
/*!50001 DROP VIEW IF EXISTS `manutenzione`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `manutenzione` AS SELECT 
 1 AS `progressivo`,
 1 AS `macchinario`,
 1 AS `data_inizio`,
 1 AS `data_fine`,
 1 AS `tipo`,
 1 AS `richiesto`,
 1 AS `valutato`,
 1 AS `completato`,
 1 AS `in_lavorazione`,
 1 AS `verificato`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `operaio`
--

DROP TABLE IF EXISTS `operaio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operaio` (
  `#ore_manutenzione` int NOT NULL,
  `dipendente` char(16) NOT NULL,
  PRIMARY KEY (`dipendente`),
  CONSTRAINT `dipendente` FOREIGN KEY (`dipendente`) REFERENCES `dipendente` (`CF`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operaio`
--

LOCK TABLES `operaio` WRITE;
/*!40000 ALTER TABLE `operaio` DISABLE KEYS */;
INSERT INTO `operaio` VALUES (12,'3333333333333335'),(0,'3333333333333336');
/*!40000 ALTER TABLE `operaio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `progetto`
--

DROP TABLE IF EXISTS `progetto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `progetto` (
  `ID` int NOT NULL,
  `prototipale` tinyint DEFAULT NULL,
  `collaudato` tinyint DEFAULT NULL,
  `commercializzato` tinyint DEFAULT NULL,
  `pilota` tinyint DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `progetto`
--

LOCK TABLES `progetto` WRITE;
/*!40000 ALTER TABLE `progetto` DISABLE KEYS */;
INSERT INTO `progetto` VALUES (123,0,0,1,0),(346,0,0,1,0),(359,0,0,1,0),(374,0,0,1,0),(863,0,0,1,0),(876,0,0,1,0);
/*!40000 ALTER TABLE `progetto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utilizzo`
--

DROP TABLE IF EXISTS `utilizzo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `utilizzo` (
  `NomeBase` varchar(20) NOT NULL,
  `NomeAccessoria` varchar(20) NOT NULL,
  PRIMARY KEY (`NomeBase`,`NomeAccessoria`),
  KEY `NomeAccessoria_idx` (`NomeAccessoria`),
  CONSTRAINT `NomeAccessoria` FOREIGN KEY (`NomeAccessoria`) REFERENCES `accessoria` (`nome`),
  CONSTRAINT `NomeBase` FOREIGN KEY (`NomeBase`) REFERENCES `base` (`nome`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utilizzo`
--

LOCK TABLES `utilizzo` WRITE;
/*!40000 ALTER TABLE `utilizzo` DISABLE KEYS */;
INSERT INTO `utilizzo` VALUES ('autoclave','crema'),('lettino','crema'),('lettino','lampada'),('lettino','termocoperta');
/*!40000 ALTER TABLE `utilizzo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `coinvolgimenti`
--

/*!50001 DROP VIEW IF EXISTS `coinvolgimenti`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `coinvolgimenti` AS select `coinvolgimento`.`dipendente` AS `dipendente` from (`coinvolgimento` join `manutenzione` on((`coinvolgimento`.`intervento` = `manutenzione`.`progressivo`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `dipendentioccupati`
--

/*!50001 DROP VIEW IF EXISTS `dipendentioccupati`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `dipendentioccupati` AS select `coinvolgimento`.`dipendente` AS `dipendente`,`coinvolgimento`.`intervento` AS `intervento`,`coinvolgimento`.`macchinario` AS `macchinario`,`coinvolgimento`.`data_inizio` AS `data_inizio`,`coinvolgimento`.`data_fine` AS `data_fine`,`coinvolgimento`.`#ore_dell'intervento` AS `#ore_dell'intervento` from `coinvolgimento` where (`coinvolgimento`.`data_fine` is null) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ingegneriliberi`
--

/*!50001 DROP VIEW IF EXISTS `ingegneriliberi`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ingegneriliberi` AS select `ingegnere`.`dipendente` AS `dipendente` from (`ingegnere` left join `ingegnerioccupati` on((`ingegnere`.`dipendente` = `ingegnerioccupati`.`dipendente`))) where (`ingegnerioccupati`.`dipendente` is null) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ingegnerioccupati`
--

/*!50001 DROP VIEW IF EXISTS `ingegnerioccupati`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ingegnerioccupati` AS select `ingegnere`.`dipendente` AS `dipendente` from (`ingegnere` join `dipendentioccupati` on((`ingegnere`.`dipendente` = `dipendentioccupati`.`dipendente`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `macchinarimanutenuti`
--

/*!50001 DROP VIEW IF EXISTS `macchinarimanutenuti`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `macchinarimanutenuti` AS select `intervento`.`macchinario` AS `macchinario` from `intervento` where (`intervento`.`tipo` = 'manutenzione') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `macchinarinonmanutenuti`
--

/*!50001 DROP VIEW IF EXISTS `macchinarinonmanutenuti`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `macchinarinonmanutenuti` AS select `macchinario`.`cod_seriale` AS `cod_seriale` from (`macchinario` left join `macchinarimanutenuti` on((`macchinario`.`cod_seriale` = `macchinarimanutenuti`.`macchinario`))) where (`macchinarimanutenuti`.`macchinario` is null) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `manutenzione`
--

/*!50001 DROP VIEW IF EXISTS `manutenzione`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `manutenzione` AS select `intervento`.`progressivo` AS `progressivo`,`intervento`.`macchinario` AS `macchinario`,`intervento`.`data_inizio` AS `data_inizio`,`intervento`.`data_fine` AS `data_fine`,`intervento`.`tipo` AS `tipo`,`intervento`.`richiesto` AS `richiesto`,`intervento`.`valutato` AS `valutato`,`intervento`.`completato` AS `completato`,`intervento`.`in_lavorazione` AS `in_lavorazione`,`intervento`.`verificato` AS `verificato` from `intervento` where ((`intervento`.`tipo` = 'manutenzione') and (`intervento`.`data_fine` is null)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-08 14:37:38
